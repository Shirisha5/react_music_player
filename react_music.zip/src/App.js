import './App.css';
import MusicPlayer from './Component/MusicPlayer/MusicPlayer';

function App() {
  return (
    <div className="app">
          <MusicPlayer />
    </div>
  );
}

export default App;
