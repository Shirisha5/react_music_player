import affection from "../../Assets/Images/Affection.jpg";
import alone from "../../Assets/Images/Alone.jpg";
import affectionSong from "../../Assets/Songs/Affection.mp3";
import aloneSong from "../../Assets/Songs/Alone.mp3"

export const songsData = [

    {
        "title": "Affection",
        "artist": "Jinsang",
        "album": "Life",
        "track": "15",
        "year": "",
        "img_src": affection,
        "src": affectionSong
    },

    {
        "title": "Alone and Lonely",
        "artist": "prxz",
        "album": " Shiloh Dynasty",
        "track": "Love Wounds",
        "year": "2",
        "img_src": alone,
        "src": aloneSong
    },

]