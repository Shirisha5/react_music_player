import React, { useRef, useState, useEffect } from 'react'
import "./Musicplayer.css";
// import sampleImg from "../../Assets/Images/sample.jpg";
import { FaPlay } from "react-icons/fa";
import { AiFillStepBackward, AiFillStepForward } from "react-icons/ai";
// import sampleAudio from "../../Assets/Songs/public_songs_Affection.mp3";
import { BsPauseFill } from "react-icons/bs";
import { songsData } from "../MusicData/data";


export default function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0.00);
  const [durationTime, setDurationTime] = useState("");
  const [progressValue, setProgressValue] = useState(0);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const [songs, setSongs] = useState([]);
  const audioElement = useRef(null);

  useEffect(() => {
    if (isPlaying) {
      audioElement.current.play();

    } else {
      audioElement.current.pause();
    }
    if (songsData.length > 0) {
      setInterval(updateProgressValue, 500);
    }
  }, [isPlaying]);



  function updateProgressValue() {
    setDurationTime(Math.floor(audioElement.current.duration));
    if (durationTime === "NaN:NaN") {
      setDurationTime("0:00")
    } else {
      setDurationTime(formatTime(Math.floor(audioElement.current.duration)));
      setCurrentTime(formatTime(Math.floor(audioElement.current.currentTime)));
      setProgressValue(Math.floor(audioElement.current.currentTime));
    }
  };

  // convert song.currentTime and song.duration into MM:SS format
  function formatTime(seconds) {
    let min = Math.floor((seconds / 60));
    let sec = Math.floor(seconds - (min * 60));
    if (sec < 10) {
      sec = `0${sec}`;
    };
    return `${min}:${sec}`;
  };

  // run updateProgressValue function every 1/2 second to show change in progressBar and song.currentTime on the DOM

  const progressChange = (e) => {
    audioElement.current.currentTime = e.target.value
  }

  const skipSong = (type) => {
    if (currentSongIndex === 0 && type === "prev") {
      setCurrentSongIndex(songsData.length - 1)
    } else if (type == "next" && currentSongIndex === (songsData.length - 1)) {
      setCurrentSongIndex(0)
    } else if (type === "next") {
      let nextIndex = currentSongIndex + 1;
      setCurrentSongIndex(nextIndex)
    }
    else if (type == "prev") {
      let prevIndex = currentSongIndex - 1;
      setCurrentSongIndex(prevIndex)
    }
  }


  return (
    <>
      {songsData.length > 0 && <div className='music_player_wrapper'>
        <div className='music_player_content'>
          <div className='music_player_head'>Now Playing</div>

          <div className='music_player_image'>
            <img src={songsData?.[currentSongIndex].img_src} alt="Album Image" />
          </div>

          <div className='music_player_song_title'>
            {songsData?.[currentSongIndex].title}
          </div>
          <div className='music_player_song_artist'>
            {songsData?.[currentSongIndex].artist}
          </div>

        </div>

        <div className='music_player_controls'>
          <audio src={songsData?.[currentSongIndex].src} ref={audioElement}></audio>
          <div className='music_player_progress'>
            <div className='music_player_times'>
              <span className='song_current_time'>{currentTime}</span>
              <span className='song_duration_time'>{durationTime}</span>
            </div>
            <div>
              <input
                type="range"
                id="progress_bar"
                min="0"
                max={durationTime}
                value={progressValue}
                onChange={(e) => progressChange(e)}
              />
            </div>

          </div>
          <div className='music_player_loop_button'>
            <div className='music_player_buttons'>
              <button id="previous_btn" onClick={() => skipSong("prev")}><AiFillStepBackward size="16px" /></button>
              <button id="play_btn" onClick={() => { setIsPlaying(!isPlaying) }}>
                {isPlaying === false ? <FaPlay color="#fff" size="18px" /> :
                  <BsPauseFill color="#fff" size="22px" />}
              </button>
              <button id="next_btn" onClick={() => skipSong("next")}><AiFillStepForward size="16px" /></button>
            </div>
          </div>
        </div>
      </div>}
    </>
  )
}
